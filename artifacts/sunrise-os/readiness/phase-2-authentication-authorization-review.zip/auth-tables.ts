/**
 * Phase 2 authentication and authorization tables.
 *
 * Five new tables added by migration 0002_authentication_authorization.sql:
 *   sos_user_accounts    — local-auth credentials, lockout, session versioning
 *   sos_sessions         — server-side session store (connect-pg-simple compatible)
 *   sos_role_assignments — DB-backed role ↔ user ↔ facility assignments
 *   sos_patient_access   — explicit patient-access assignments
 *   sos_auth_audit       — append-only authentication/authorization audit log
 */

import {
  pgTable,
  text,
  uuid,
  integer,
  timestamp,
  index,
  uniqueIndex,
  check,
  foreignKey,
  jsonb,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { sosOrganizations } from "./sunrise-os";
import { sosFacilities } from "./sunrise-os";
import { sosUserIdentityRefs } from "./sunrise-os";
import { sosPatients } from "./sunrise-os";

// ── sos_user_accounts ───────────────────────────────────────────────────────
export const sosUserAccounts = pgTable(
  "sos_user_accounts",
  {
    id:                uuid("id").primaryKey().defaultRandom(),
    orgId:             uuid("org_id").notNull()
                         .references(() => sosOrganizations.id, { onDelete: "cascade" }),
    userIdentityRefId: uuid("user_identity_ref_id").notNull(),
    email:             text("email").notNull(),
    passwordHash:      text("password_hash"),        // Argon2id; NULL for SSO-only
    status:            text("status").notNull().default("active"),
    emailVerifiedAt:   timestamp("email_verified_at", { withTimezone: true }),
    failedLoginCount:  integer("failed_login_count").notNull().default(0),
    lockedUntil:       timestamp("locked_until", { withTimezone: true }),
    lastLoginAt:       timestamp("last_login_at", { withTimezone: true }),
    passwordChangedAt: timestamp("password_changed_at", { withTimezone: true }),
    sessionVersion:    integer("session_version").notNull().default(0),
    mfaStatus:         text("mfa_status").notNull().default("disabled"),
    createdAt:         timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt:         timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    disabledAt:        timestamp("disabled_at", { withTimezone: true }),
  },
  (t) => ({
    idxOrgId:    index("idx_sos_user_accounts_org_id").on(t.orgId),
    uniqueOrgId: uniqueIndex("idx_sos_user_accounts_org_id_id").on(t.orgId, t.id),
    uniqueEmail: uniqueIndex("idx_sos_user_accounts_org_email").on(t.orgId, t.email),
    ckStatus:    check(
      "ck_sos_user_accounts_status",
      sql`${t.status} IN ('active', 'disabled', 'locked', 'pending_verification')`,
    ),
    ckMfaStatus: check(
      "ck_sos_user_accounts_mfa_status",
      sql`${t.mfaStatus} IN ('disabled', 'totp_pending', 'totp_active', 'webauthn_active')`,
    ),
    fkOrgIdentityRef: foreignKey({
      columns: [t.orgId, t.userIdentityRefId],
      foreignColumns: [sosUserIdentityRefs.orgId, sosUserIdentityRefs.id],
      name: "fk_sos_user_accounts_org_identity_ref",
    }).onDelete("cascade"),
  }),
);
export type SosUserAccount = typeof sosUserAccounts.$inferSelect;
export type InsertSosUserAccount = typeof sosUserAccounts.$inferInsert;

// ── sos_sessions ─────────────────────────────────────────────────────────────
// connect-pg-simple requires: sid TEXT PK, sess JSONB, expire TIMESTAMPTZ.
// Extra columns are for compliance tracking and revocation.
export const sosSessions = pgTable(
  "sos_sessions",
  {
    sid:               text("sid").primaryKey(),
    sess:              jsonb("sess").notNull(),
    expire:            timestamp("expire", { withTimezone: true }).notNull(),
    userId:            uuid("user_id"),
    orgId:             uuid("org_id"),
    sessionVersion:    integer("session_version"),
    ipAddress:         text("ip_address"),
    userAgentSummary:  text("user_agent_summary"),
    revokedAt:         timestamp("revoked_at", { withTimezone: true }),
    revokedReason:     text("revoked_reason"),
  },
  (t) => ({
    idxExpire:  index("idx_sos_sessions_expire").on(t.expire),
    idxUserId:  index("idx_sos_sessions_user_id").on(t.userId),
  }),
);
export type SosSession = typeof sosSessions.$inferSelect;

// ── sos_role_assignments ────────────────────────────────────────────────────
export const sosRoleAssignments = pgTable(
  "sos_role_assignments",
  {
    id:              uuid("id").primaryKey().defaultRandom(),
    orgId:           uuid("org_id").notNull()
                       .references(() => sosOrganizations.id, { onDelete: "cascade" }),
    userId:          uuid("user_id").notNull(),
    staffProfileId:  uuid("staff_profile_id"),
    roleId:          text("role_id").notNull(),    // code-defined role IDs
    facilityId:      uuid("facility_id"),           // NULL = org-wide assignment
    programId:       text("program_id"),
    status:          text("status").notNull().default("active"),
    effectiveAt:     timestamp("effective_at", { withTimezone: true }).defaultNow().notNull(),
    expiresAt:       timestamp("expires_at", { withTimezone: true }),
    createdAt:       timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    createdByUserId: uuid("created_by_user_id"),
  },
  (t) => ({
    idxOrgUser:   index("idx_sos_role_assignments_org_user").on(t.orgId, t.userId),
    idxFacility:  index("idx_sos_role_assignments_facility").on(t.facilityId),
    ckStatus:     check(
      "ck_sos_role_assignments_status",
      sql`${t.status} IN ('active', 'revoked', 'expired')`,
    ),
    fkOrgUser: foreignKey({
      columns: [t.orgId, t.userId],
      foreignColumns: [sosUserAccounts.orgId, sosUserAccounts.id],
      name: "fk_sos_role_assignments_org_user",
    }).onDelete("cascade"),
  }),
);
export type SosRoleAssignment = typeof sosRoleAssignments.$inferSelect;
export type InsertSosRoleAssignment = typeof sosRoleAssignments.$inferInsert;

// ── sos_patient_access ──────────────────────────────────────────────────────
export const sosPatientAccess = pgTable(
  "sos_patient_access",
  {
    id:               uuid("id").primaryKey().defaultRandom(),
    orgId:            uuid("org_id").notNull()
                        .references(() => sosOrganizations.id, { onDelete: "cascade" }),
    facilityId:       uuid("facility_id").notNull(),
    patientId:        uuid("patient_id").notNull(),
    userId:           uuid("user_id").notNull(),
    relationshipType: text("relationship_type").notNull().default("caseload_member"),
    effectiveAt:      timestamp("effective_at", { withTimezone: true }).defaultNow().notNull(),
    expiresAt:        timestamp("expires_at", { withTimezone: true }),
    status:           text("status").notNull().default("active"),
    createdByUserId:  uuid("created_by_user_id"),
    createdAt:        timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => ({
    idxPatient: index("idx_sos_patient_access_patient").on(t.orgId, t.patientId),
    idxUser:    index("idx_sos_patient_access_user").on(t.orgId, t.userId),
    ckStatus:   check(
      "ck_sos_patient_access_status",
      sql`${t.status} IN ('active', 'revoked', 'expired')`,
    ),
    ckRelationship: check(
      "ck_sos_patient_access_relationship",
      sql`${t.relationshipType} IN ('primary_counselor', 'caseload_member', 'covering_staff', 'observer', 'authorized_reviewer')`,
    ),
    fkOrgFacility: foreignKey({
      columns: [t.orgId, t.facilityId],
      foreignColumns: [sosFacilities.orgId, sosFacilities.id],
      name: "fk_sos_patient_access_org_facility",
    }).onDelete("restrict"),
    fkOrgPatient: foreignKey({
      columns: [t.orgId, t.patientId],
      foreignColumns: [sosPatients.orgId, sosPatients.id],
      name: "fk_sos_patient_access_org_patient",
    }).onDelete("cascade"),
    fkOrgUser: foreignKey({
      columns: [t.orgId, t.userId],
      foreignColumns: [sosUserAccounts.orgId, sosUserAccounts.id],
      name: "fk_sos_patient_access_org_user",
    }).onDelete("cascade"),
  }),
);
export type SosPatientAccess = typeof sosPatientAccess.$inferSelect;
export type InsertSosPatientAccess = typeof sosPatientAccess.$inferInsert;

// ── sos_auth_audit ──────────────────────────────────────────────────────────
// Append-only audit log. Application convention: no UPDATE or DELETE.
export const sosAuthAudit = pgTable(
  "sos_auth_audit",
  {
    id:               uuid("id").primaryKey().defaultRandom(),
    orgId:            uuid("org_id"),
    userId:           uuid("user_id"),
    staffId:          uuid("staff_id"),
    sessionId:        text("session_id"),     // session reference, NOT the token
    eventType:        text("event_type").notNull(),
    outcome:          text("outcome").notNull().default("success"),
    reasonCode:       text("reason_code"),
    targetUserId:     uuid("target_user_id"),
    ipAddress:        text("ip_address"),
    userAgentSummary: text("user_agent_summary"),
    metadata:         jsonb("metadata"),
    createdAt:        timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => ({
    idxUserId:    index("idx_sos_auth_audit_user_id").on(t.userId),
    idxOrgId:     index("idx_sos_auth_audit_org_id").on(t.orgId),
    idxCreatedAt: index("idx_sos_auth_audit_created_at").on(t.createdAt),
    ckOutcome:    check(
      "ck_sos_auth_audit_outcome",
      sql`${t.outcome} IN ('success', 'failure', 'error')`,
    ),
  }),
);
export type SosAuthAudit = typeof sosAuthAudit.$inferSelect;
export type InsertSosAuthAudit = typeof sosAuthAudit.$inferInsert;
